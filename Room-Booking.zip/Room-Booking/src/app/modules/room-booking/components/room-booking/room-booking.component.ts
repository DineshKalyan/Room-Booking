import { Component, OnInit } from '@angular/core';

interface BookingDetails {
  roomCount: number;
  adultCount: number;
  childrenCount: number;
}

@Component({
  selector: 'app-room-booking',
  templateUrl: './room-booking.component.html',
  styleUrls: ['./room-booking.component.scss']
})
export class RoomBookingComponent implements OnInit {
  bookingInfo: BookingDetails;
  maxRoom = 5;
  maxPersonRoomCount = 4;

  constructor() { }

  ngOnInit(): void {
    this.bookingInfo = {
      roomCount: 1,
      adultCount: 1,
      childrenCount: 0
    }
  }

  changeRoomCount(value: number) {
    const newRoomCount = this.bookingInfo.roomCount + value;
    if (newRoomCount > 0 && newRoomCount <= this.maxRoom) {
      this.bookingInfo.roomCount = newRoomCount;
      if (value === 1) {
        if (this.bookingInfo.adultCount < newRoomCount) {
          this.bookingInfo.adultCount += 1;
        }
      } else {
        if (newRoomCount * this.maxPersonRoomCount < (this.bookingInfo.adultCount + this.bookingInfo.childrenCount)) {
          while (newRoomCount * this.maxPersonRoomCount < (this.bookingInfo.adultCount + this.bookingInfo.childrenCount) && this.bookingInfo.childrenCount > 0) {
            this.bookingInfo.childrenCount--;
          }

          while (newRoomCount * this.maxPersonRoomCount < (this.bookingInfo.adultCount + this.bookingInfo.childrenCount) && this.bookingInfo.adultCount > 0) {
            this.bookingInfo.adultCount--;
          }
        }
      }
    }
  }

  changeAdultCount(value: number) {
    if (value === 1) {
      if (this.bookingInfo.roomCount === this.maxRoom && this.bookingInfo.roomCount * this.maxPersonRoomCount < (this.bookingInfo.adultCount + this.bookingInfo.childrenCount + 1)) {
        return;
      }
      if (this.bookingInfo.roomCount !== this.maxRoom &&
        this.bookingInfo.roomCount * this.maxPersonRoomCount < (this.bookingInfo.adultCount + this.bookingInfo.childrenCount + 1)) {
        this.bookingInfo.roomCount += 1;
      }
      this.bookingInfo.adultCount += 1;
    } else {
      if (this.bookingInfo.adultCount + value > 0) {
        this.bookingInfo.adultCount -= 1;
        if (this.bookingInfo.roomCount > this.bookingInfo.adultCount) {
          this.bookingInfo.roomCount--;
        }
        while (this.bookingInfo.roomCount * this.maxPersonRoomCount < (this.bookingInfo.adultCount + this.bookingInfo.childrenCount) && this.bookingInfo.childrenCount > 0) {
          this.bookingInfo.childrenCount--;
        }
      }
    }
  }

  changeChildrenCount(value: number) {
    if (value === 1) {
      if (this.bookingInfo.roomCount === this.maxRoom && this.bookingInfo.roomCount * this.maxPersonRoomCount < (this.bookingInfo.adultCount + this.bookingInfo.childrenCount + 1)) {
        return;
      }
      if (this.bookingInfo.roomCount !== this.maxRoom &&
        this.bookingInfo.roomCount * this.maxPersonRoomCount < (this.bookingInfo.adultCount + this.bookingInfo.childrenCount + 1)) {
        this.bookingInfo.roomCount += 1;
      }
      if (this.bookingInfo.roomCount > this.bookingInfo.adultCount) {
        this.bookingInfo.adultCount += 1;
      }
      this.bookingInfo.childrenCount += 1;
    } else {
      if (this.bookingInfo.childrenCount + value > -1) {
        this.bookingInfo.childrenCount -= 1;
      }
    }
  }

  checkDisability(type: string, value: string): boolean {
    let disable = false;
    if (type === 'adult') {
      if (value === 'decrease') {
        disable = this.bookingInfo.adultCount === 1;
      }
    } else {
      if (value === 'decrease') {
        disable = this.bookingInfo.childrenCount === 0;
      }
    }
    if (this.bookingInfo.adultCount + this.bookingInfo.childrenCount === this.bookingInfo.roomCount * this.maxPersonRoomCount &&
      this.bookingInfo.roomCount === this.maxRoom && value === 'increase') {
      disable = true;
    }
    return disable;
  }

}
