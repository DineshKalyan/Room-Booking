import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RootComponent } from './components/root/root.component';
import { RoomBookingComponent } from './modules/room-booking/components/room-booking/room-booking.component';

const routes: Routes = [
  {
    path: '', component: RootComponent, children: [
      { path: 'booking', component: RoomBookingComponent }
    ]
  },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
